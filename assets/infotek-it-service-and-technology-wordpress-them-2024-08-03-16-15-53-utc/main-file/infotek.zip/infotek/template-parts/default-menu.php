<?php

// Fallback Menu

?>

<div class="btn-wrap menu-set-up">
    <a class="boxed-btn" href="<?php echo admin_url('nav-menus.php'); ?>"><?php esc_html_e( 'Set Up Menu', 'infotek' ); ?></a>
</div>