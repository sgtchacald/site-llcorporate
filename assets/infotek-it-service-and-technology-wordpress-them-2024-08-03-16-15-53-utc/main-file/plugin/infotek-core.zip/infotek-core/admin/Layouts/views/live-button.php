<# if ( '' != livelink ) { #>
	<a class="elementor-template-library-template-action imaddons-preview-button-live"  href="{{livelink}}" target="_blank">
		<i class="eicon-editor-external-link"></i>
		<span class="elementor-button-title"><?php
			esc_html_e( 'Live Preview', 'imaddons' );
		?></span>
	</a>
<# } #>