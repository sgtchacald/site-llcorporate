<?php
/**
 * templates loader view
 */

?>
<div class="imaddons-filters-list"></div>
<div class="imaddons-templates-wrap">
	<div class="imaddons-keywords-list"></div>
	<div class="imaddons-templates-list"></div>
</div>