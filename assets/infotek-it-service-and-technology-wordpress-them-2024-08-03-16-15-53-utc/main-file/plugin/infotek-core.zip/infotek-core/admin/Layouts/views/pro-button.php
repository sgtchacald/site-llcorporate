<?php include('live-button.php'); ?>

<a  href="#" target="_blank" >
	<button class="elementor-template-library-template-action imaddons-preview-button-go-pro imaddons-template-library-template-insert imaddons-preview-button-go-pro elementor-button elementor-button-success" >
		<i class="eicon-heart"></i><span class="elementor-button-title"><?php
			esc_html_e( 'Go Pro', 'imaddons' );
		?></span>
	</button>
</a>