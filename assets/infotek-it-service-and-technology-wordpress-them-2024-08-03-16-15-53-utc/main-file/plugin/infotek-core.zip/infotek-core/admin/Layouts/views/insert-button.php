<?php include('live-button.php'); ?>

<button class="elementor-template-library-template-action imaddons-template-library-template-insert elementor-button elementor-button-success">
	<i class="eicon-file-download"></i><span class="elementor-button-title"><?php
		esc_html_e( 'Insert', 'imaddons' );
	?></span>
</button>