<?php
/**
 * Templates list view
 */
?>
<div id="imaddons-template-library-templates-container"></div>